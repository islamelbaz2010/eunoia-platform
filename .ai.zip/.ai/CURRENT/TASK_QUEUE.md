# Task Queue

**Updated:** 2026-07-21

## Done

**Session 1 (2026-07-21):**
- Show monthly plan usage on `/dashboard`.
- Show current plan and monthly usage on `/dashboard/settings`.
- Add tests for `checkPlanLimit`.
- Add tests for `checkRateLimit`.
- Restore lint command compatibility with Next 16 / ESLint 9.
- Hide raw dashboard error messages from customers.
- Add dashboard error reference tests.
- Add tests for `research-service.ts`, `ai-analysis.ts`, and `search-provider.ts`.
- Add quota-blocked upgrade CTA in dashboard research flows.
- Add failed-request recovery cards and retry links in report history.
- Add baseline Privacy Policy and Terms pages with legal-review placeholders.
- Add lightweight health-check endpoint for uptime monitoring.

**Session 2 (2026-07-21):**
- Add account data export (`/api/account/export`).
- Add account deletion with cascade (`/api/account/delete`).
- Add Download My Data + Delete Account UI to Settings.
- Add Supabase admin client (`lib/supabase/admin.ts`).
- Add admin identity check (`lib/admin/auth.ts`).
- Add admin/ops console (`/dashboard/admin`, `/api/admin/users`, `/api/admin/users/[id]/plan`).
- Add conditional Admin Console link in sidebar.
- Add quota warning banner to dashboard (80%/100%).
- Add audit log table SQL (`supabase/audit-log.sql`).
- Add `lib/admin/audit.ts` — writes to audit_log on plan changes and account deletions.
- Add 2-step onboarding product tour to `/dashboard/onboarding`.
- Convert analytics page to server component with live user research stats.
- Remove dead-code PLAN_LIMITS/PLAN_LABELS from workspace.types.ts.
- Document plan model architecture split in both types files.

## Current

- Blocked on deployment-environment configuration and provider decisions.

## Next

1. Set `SUPABASE_SERVICE_ROLE_KEY` in Vercel env vars (enables admin console and account deletion).
2. Set `ADMIN_EMAILS` in Vercel env vars (comma-separated admin email list).
3. Run `supabase/audit-log.sql` in Supabase SQL Editor.
4. Choose billing provider → implement Stripe checkout + webhook to write `user_plans`.
5. Choose APM/logging provider → implement structured error monitoring.
6. Confirm sender/domain → implement authenticated user email notifications.
7. Send Privacy/Terms to legal for review and update the placeholder text.

## Blocked

- Stripe or equivalent billing integration: requires provider decision and secrets.
- APM/structured monitoring integration: requires provider decision and project token/DSN.
- Authenticated user notification emails: requires sender/domain and notification policy decision.
- Final Privacy Policy and Terms: requires legal review.
- Admin console functionality: requires `SUPABASE_SERVICE_ROLE_KEY` + `ADMIN_EMAILS` in production env.
