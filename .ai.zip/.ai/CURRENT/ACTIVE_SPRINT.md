# Active Sprint

**Updated:** 2026-07-21

## Sprint Name

Commercial Readiness Visibility & Trust Sprint

## Sprint Objective

Convert existing server-side enforcement and operational hygiene into customer-visible, production-safe product behavior without requiring new third-party billing or monitoring secrets.

## Completed

**Session 1:**
- Usage meter on the main dashboard.
- Plan and monthly usage summary in Settings.
- Working `npm run lint` command for the current Next/ESLint stack.
- Unit tests for plan enforcement and rate limiting.
- Customer-safe dashboard error boundary.
- Unit tests for dashboard error references.
- Focused research-service, AI-analysis, and search-provider tests.
- Quota-blocked upgrade CTA in dashboard research flows.
- Failed-request recovery cards and retry links in report history.
- Baseline Privacy Policy and Terms pages.
- Public `/api/health` endpoint with regression coverage.

**Session 2:**
- Account data export (`/api/account/export` → Download My Data in Settings).
- Account deletion (`/api/account/delete` + confirmation dialog in Settings).
- Admin/ops console (`/dashboard/admin`) with user list, usage, and plan management.
- Admin API routes (`/api/admin/check`, `/api/admin/users`, `/api/admin/users/[id]/plan`).
- Admin Console sidebar link (shown only to admin users via `/api/admin/check`).
- Quota warning banner on dashboard at ≥80% and 100% usage.
- Audit log infrastructure (`supabase/audit-log.sql`, `lib/admin/audit.ts`).
- Audit log wired to plan-change and account-delete events.
- 2-step onboarding product tour.
- Market Intelligence page upgraded with live per-user research stats.
- Plan model architecture documented and dead code removed from workspace.types.ts.

## In Progress

- None. All repository-controllable tasks are complete.

## Not Started

- None for the current unblocked commercial-readiness slice.

## Blocked

- Stripe or equivalent billing integration: requires provider decision and secrets.
- APM/structured monitoring integration: requires provider decision and project token/DSN.
- Admin/ops console at runtime: requires `SUPABASE_SERVICE_ROLE_KEY` + `ADMIN_EMAILS` in production env.
- Authenticated user notification emails: requires sender/domain and notification policy decision.
- Final Privacy Policy and Terms: requires legal review.
- `supabase/audit-log.sql`: must be applied in Supabase SQL Editor before audit logging is active.
